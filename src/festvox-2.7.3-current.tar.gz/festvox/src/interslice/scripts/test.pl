use scripts::syllabifier;

my $word = "tiisukun:t:aanu";

print &Phonification($word)."\n";

